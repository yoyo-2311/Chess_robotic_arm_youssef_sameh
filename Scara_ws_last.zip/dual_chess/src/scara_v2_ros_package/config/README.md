Controller configuration can be added here later.
