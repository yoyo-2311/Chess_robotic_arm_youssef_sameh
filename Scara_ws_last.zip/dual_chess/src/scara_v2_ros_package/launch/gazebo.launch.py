from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch.substitutions import PathJoinSubstitution
from pathlib import Path
import os
import xacro


def generate_launch_description():
    pkg = get_package_share_directory('scara_v2_ros_package')
    gz_pkg = get_package_share_directory('ros_gz_sim')
    model = os.path.join(pkg, 'urdf', 'scara_v2.urdf.xacro')
    robot_xml = xacro.process_file(model).toxml()
    # Let Gazebo resolve package:// mesh URIs from the installed share directory.
    existing = os.environ.get('GZ_SIM_RESOURCE_PATH', '')
    resource_path = os.pathsep.join(filter(None, [str(Path(pkg).parent), existing]))

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', resource_path),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(gz_pkg, 'launch', 'gz_sim.launch.py')),
            launch_arguments={'gz_args': '-r empty.sdf'}.items()),
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             parameters=[{'robot_description': robot_xml, 'use_sim_time': True}],
             output='screen'),
        # Joint state publisher only drives ROS TF; it does not command Gazebo physics.
        Node(package='joint_state_publisher', executable='joint_state_publisher',
             output='screen'),
        Node(package='ros_gz_bridge', executable='parameter_bridge',
             arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
             output='screen'),
        TimerAction(period=4.0, actions=[
            Node(package='ros_gz_sim', executable='create',
                 arguments=['-world', 'empty', '-name', 'scara_v2',
                            '-topic', 'robot_description', '-z', '0.15'],
                 output='screen')
        ]),
    ])
